import React from 'react'

export default function Success(props) {
   
  	return (
   
        <div className="container" id="welcome">
        	<p id="thank">Thankyou for registring.</p>
   		</div>
   
    );
}

