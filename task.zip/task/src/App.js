import React, {Component} from 'react'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import PersonalForm from './components/PersonalForm'
import CompanyDetails from './components/CompanyDetails'
import EmailDetails from './components/EmailDetails';
import './style/style.css';
import Success from './components/Success';

class App extends Component {
  constructor() {
    super();
      this.state = 
      { 
        tabIndex: 0,
        name: "",
        logo: '/images/default.jpg',
        gender: '',
        country: '',
        state: '',
        phone: '',
        otp: '',
        companyname : "",
        emailId: "",
        jobtitle:"",
        experience:"",
        condition: true,
        file:'',
        display:0,
          errors:{
          name: "",
          gender: '',
          country: '',
          state: '',
          phone: '',
          companyname : "",
          emailId: "",
          jobtitle:"",
          experience:"",
          condition:'',
          file:'',
          otp:''
        }
       
      };
      this.handleChange = this.handleChange.bind(this);
      this.handleNext = this.handleNext.bind(this);
      this.handleBack = this.handleBack.bind(this);
      this.onChangeFile = this.onChangeFile.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
      this.handleSendOtp = this.handleSendOtp.bind(this);  
      this.handleOtp = this.handleOtp.bind(this);
  } 

  handleOtp(data) {
    this.setState({ 
      otp: data
    });

    let errors = this.state.errors;
    console.log(this.state.otp)
    if (data !== '' && this.state.otp.length < 2) {
        errors.otp = "Please Enter a 4 digit OTP";
    } else {
        errors.otp = "";
    }    
    this.setState({errors});
  }

  onChangeFile(e) {
    e.preventDefault();
    let errors = this.state.errors;
    let reader = new FileReader();
    let files = e.target.files; 
    let file = e.target.files[0];
    if (!files[0].name.match(/\.(jpg|jpeg|png|gif)$/)) {
      errors.file = 'Only jpeg,png and jpg accepted';
      this.setState({errors})
    } else {
    reader.onloadend = () => {
      this.setState({
        file: file,
        logo: reader.result
      });
    }
    reader.readAsDataURL(file)
    if (this.state.logo !== "") {
        errors.file = "";
    }
    }

  }

  handleSubmit() {
    let errors = this.state.errors;
    if (this.state.otp === '') {
      errors.otp= 'OTP must be filled out';
    }
    this.setState({errors});

      localStorage.setItem('document', this.state);
      this.setState({
        display:1
      }) 
    }
  

  handleNext() {
  
    let errors = this.state.errors;
    if (this.state.name === '') {
      errors.name = 'Name must be filled out';
    }
    
    if (this.state.gender === '') {
      errors.gender = 'Gender must be filled out';
    }

    if (this.state.country === '') {
      errors.country = 'Country must be selected';
    }

    if (this.state.state === '') {
      errors.state = 'State must be selected';
    }

    if (this.state.phone === '') {
      errors.phone = 'Phone number is needed';
    }
    
    this.setState({errors});
    if (errors.name === '' && 
      errors.gender === '' && 
      errors.country === '' && 
      errors.state === '' && 
      errors.phone === ''      
      ) {
      let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal+1,
        //tab1:'&#10003'
      });
       
      document.getElementById("tab1").innerHTML = "&#10003";
    } 
  }

  handleSendOtp() {
    let errors = this.state.errors;
    console.log(errors)
    if (this.state.file === '') {
      errors.file = 'Please upload your company logo';
    }

    if (this.state.companyname === '') {
      errors.companyname = 'Company Name must be filled out';
    }
    if (this.state.emailId === '') {
      errors.emailId = 'EmaliId must be filled out';
    }
    if (this.state.jobtitle === '') {
      errors.jobtitle = 'Jobtitle must be filled out';
    }
    if (this.state.experience === '') {
      errors.experience = 'Experience must be filled out';
    }
    if (this.state.condition === false) {
      errors.condition= 'Please check the terms and conditions';
    }

    this.setState({errors});
    
    if ( errors.companyname === '' &&
         errors.emailId === '' &&
         errors.jobtitle === '' &&
         errors.experience === '' &&
         errors.condition === '' &&
         errors.file === ''
      ) {
      
      let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal+1
      });
      document.getElementById("tab2").innerHTML = "&#10003";
    } 

  }

  handleChange(event) {

    const target = event.target;
    const value = target.name === 'condition' ? target.checked : target.value;
    const name = target.name;
   
    this.setState({
      [name]: value
    });

    let errors = this.state.errors;
     switch (name) {
      case 'name':
      
      errors.name = (value.length === null)? 'Name must be filled Out' : '';
      break; 

      case 'gender':
      errors.gender = (value.length === null)? 'Gender must be filled Out' : '';
      break;       

      case 'country':
      errors.country = (value.length === null)? 'Please Select a country' : '';
      break;       

      case 'state':
      errors.state = (value.length === null)? 'Please Select a state' : '';
      break;       

      case 'companyname':
      errors.companyname = (value.length === null)? 'Company Name must be filled Out' : '';
      break;       

      case 'jobtitle':
      errors.jobtitle = (value.length === null)? 'Jobtitle is required' : '';
      break;       

      case 'experience':
      errors.experience = (value.match(/^[0-9\b]+$/i) || value.length === '') ? '' : 'Experience must be a number';
      break;       

      case 'condition':
      errors.condition = (value.checked === false)? 'Please accepte the terms and conditions' : '';
      break;       

      case 'emailId':
      errors.emailId = (value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) || value.length === '') ? '' : 'Please Enter a valid mail!';
      break;
      case 'phone':
        errors.phone = '';
        if (value.length < 10 || value.length === '') {
          errors.phone = 'Contact Number must be more than 10';
        }
        if (value.length > 15) {
          errors.phone =  'Contact Number must be less than 15'; 
        }
      break;

      case 'file':
      errors.file = (value.checked === false)? 'Please accepte the terms and conditions' : '';
      break;           

      default:
      break;
    }

    this.setState({errors, [name]: value});
 
  } 

  handleBack() {
    let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal-1
    });
  }

  render() {
    if (this.state.display === 0) {
    return (
      <div className="Container">
      <Tabs selectedIndex={this.state.tabIndex}  className={'tab-wrap'} >
        <TabList>
          <Tab ><span id = "tab1">1</span> Personal Details</Tab>
          <Tab onClick = {this.handleNext}><span id = "tab2">2</span> Company Details</Tab>
          <Tab onClick = {this.handleSendOtp}><span id = "tab3">3</span> Email Verification</Tab>
        </TabList>

        <TabPanel>
          <PersonalForm
            name = {this.state.name}
            country = {this.state.country}
            state = {this.state.state}
            gender = {this.state.gender}
            phone = {this.state.phone}
            errors = {this.state.errors}
            handleChange = {this.handleChange}
            changeNext = {this.handleNext}
            handleRadio = {this.handleRadio}
            handleFlag = {this.handleFlag}
            handleState = {this.handleState}
          />
        </TabPanel>
        <TabPanel>
          <CompanyDetails
            companyname = {this.state.companyname}
            logo = {this.state.logo}
            errors = {this.state.errors}
            emailId = {this.state.emailId}
            jobtitle = {this.state.jobtitle}
            experience = {this.state.experience}
            condition = {this.state.condition}
            handleChange = {this.handleChange}
            changeNext = {this.handleSendOtp}
            changeBack = {this.handleBack}
            onChangeFile = {this.onChangeFile}
        />
        </TabPanel>
        <TabPanel>
          <EmailDetails
            otp = {this.state.otp}
            errors = {this.state.errors}
            handleOtp = {this.handleOtp}  
            changeBack = {this.handleBack}
            handleSubmit = {this.handleSubmit}
            onKeyUpEvent = {this.onKeyUpEvent}
            handleChange = {this.handleChange}
          />
        </TabPanel>
      </Tabs>
      </div>
      );} else {
      return (
      <Success/>
      );
    }
  }
}

export default App;