import React, {Component} from 'react'
import OtpInput from 'react-otp-input';

class EmailDetails extends Component {

  render() {
    
    return (
        <React.Fragment>
            <div className="container">
                <div className="form-wrap otp">
                <div className="form-group otp-form">
                    <label htmlFor="otp">Enter Your Code:</label>
                    <OtpInput  
                      numInputs={4}
                      separator={<span>-</span>}
                      value={this.props.otp}
                      onChange = {this.props.handleOtp}
                    />
                    <span className='error'>
                      { this.props.errors.otp.length > 0 ? this.props.errors.otp : ''}
                    </span>
                </div>
                <button className="btn btn-primary" 
                onClick={this.props.changeBack} >Back</button>
                <button className="btn btn-secondary" 
                type="submit" 
                onClick={this.props.handleSubmit}>Verify</button>
            </div>
        </div>
    </React.Fragment>
    );
}
}
export default EmailDetails;
