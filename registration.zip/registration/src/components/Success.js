import React from 'react'

export default function Success(props) {
   
  	return (
   
        <div className="container" id="welcome">
        	<p id="thank">You have registered successfully.</p>
   		</div>
   
    );
}

