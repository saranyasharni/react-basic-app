import React, {Component} from 'react'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import PersonalForm from './components/PersonalForm'
import CompanyDetails from './components/CompanyDetails'
import EmailDetails from './components/EmailDetails';
import './style/style.css';
import { BrowserRouter as Router,
Switch,
Route,
Redirect } from 'react-router-dom';
import Success from './components/Success';

class App extends Component {
  constructor() {
    super();
      this.state = 
      { 
        tabIndex: 0,
        name: "",
        gender: '',
        country: '',
        state: '',
        phone: '',
        otp: '',
        errors:{
        name: "",
        gender: '',
        country: '',
        state: '',
        phone: '',
        companyname : "",
        emailId: "",
        jobtitle:"",
        experience:"",
        condition:false,
        file:'',
        otp:''
        },
        companyname : "",
        emailId: "",
        jobtitle:"",
        experience:"",
        condition:true,
        file:'',
        display:0
      };
      this.handleChange = this.handleChange.bind(this);
      this.handleRadio = this.handleRadio.bind(this);
      this.handleNext = this.handleNext.bind(this);
      this.handleFlag = this.handleFlag.bind(this);
      this.handleState = this.handleState.bind(this);
      this.handleBack = this.handleBack.bind(this);
      this.onChangeFile = this.onChangeFile.bind(this);
      this.handleOtp = this.handleOtp.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
      this.handleSendOtp = this.handleSendOtp.bind(this);
  }

  handleOtp(data) {
    
    let otp = [];
    otp.push(data);
    
    this.setState({ 
      otp: data
    });
  }
  onChangeFile(event) {

    let file = event.target.files;
    let errors = this.state.errors;
    if (!file[0].name.match(/\.(jpg|jpeg|png|gif)$/)) {

      errors.file = 'Only jpeg,png and jpg accepted';

      this.setState({file:errors.file})
    } else {
      errors.file = 'Uploaded Successfully';
      this.setState({file:errors.file})
    }
  }

  handleSubmit() {
    
    let errors = this.state.errors;
    if (this.state.otp === '') {
      errors.otp= 'OTP must be filled out';
    }
    this.setState({errors});

    let fromData = this.state;
    if (fromData.name === "" ||
      fromData.phone === "" ||
      fromData.gender === "" ||
      fromData.country === "" ||
      fromData.state === ""
      ) {
      let tabVal = 0;
      this.setState({ 
        tabIndex: tabVal
      });
    } else if (
      fromData.companyname === "" ||
      fromData.emailId === "" ||
      fromData.jobtitle === "" ||
      fromData.experience === "" ||
      fromData.condition === false
      ) {
      let tabVal = 1;
      this.setState({ 
        tabIndex: tabVal
      });

    } else {
      localStorage.setItem('document', this.state);
      this.setState({
        display:1
      }) 
    }
  }
  handleNext() {
    let errors = this.state.errors;
    if (this.state.name === '') {
      errors.name = 'Name must be filled out';
    }
    
    if (this.state.gender === '') {
      errors.gender = 'Gender must be filled out';
    }

    if (this.state.country === '') {
      errors.country = 'Country must be selected';
    }

    if (this.state.state === '') {
      errors.state = 'state must be selected';
    }

    if (this.state.phone === '') {
      errors.phone = 'Phone number is needed';
    }
    
    this.setState({errors});
    if (errors.name === '' && 
      errors.gender === '' && 
      errors.country === '' && 
      errors.state === '' && 
      errors.phone === ''      
      ) {
      let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal+1
      });
    } 
  }

  handleSendOtp() {
     let errors = this.state.errors;
    if (this.state.companyname === '') {
      errors.companyname = 'Company Name must be filled out';
    }
    if (this.state.emailId === '') {
      errors.emailId = 'EmaliId must be filled out';
    }
    if (this.state.jobtitle === '') {
      errors.jobtitle = 'jobtitle must be filled out';
    }
    if (this.state.experience === '') {
      errors.experience = 'Experience must be filled out';
    }
    if (this.state.condition === false) {
      errors.condition= 'Please check the terms and conditions';
    }
    this.setState({errors});
    if ( errors.companyname === '' &&
         errors.emailId === '' &&
         errors.jobtitle === '' &&
         errors.experience === '' &&
         errors.condition === false
      ) {
      let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal+1
      });
    } 

  }

  handleChange(event) {
    event.preventDefault();
    const target = event.target;
    const value = target.name === 'condition' ? target.checked : target.value;
    const name = target.name;
    this.setState({ 
      [name]: value
    });

    let errors = this.state.errors;
     switch (name) {
      case 'name':

      if (this.state.name !== "") {
        errors.name = "";
      }
      case 'emailId':
      errors.emailId = (value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) || value.length === '') ? '' : 'Please Enter a valid mail!';
      break;

      case 'phone':
      errors.phone = '';
      if (value.length < 10 || value.length === '') {
        errors.phone = 'Contact Number must be more than 10';
      }
      if (value.length > 15) {
        errors.phone =  'Contact Number must be less than 15'; 
      }

      break;
      default:
      
    }

    this.setState({errors, [name]: value});
 
  } 
  handleRadio(event) {
    
    this.setState({ 
      gender: event.target.value
    });
   }

   handleFlag(event) {

    this.setState({ 
      country: event.target.value
    });

    let errors = this.state.errors;
    console.log(this.state.country);
    if (this.state.country !== "") {
      errors.country = "";
    }
   } 

  handleState(event) {  
    this.setState({ 
      state:event.target.value
    });
    let errors = this.state.errors;
    if (this.state.state !== "") {
      errors.state = "";
    }
  }    
  handleBack() {
    let tabVal = this.state.tabIndex;
      this.setState({ 
        tabIndex: tabVal-1
    });
  }
  render() {
    if (this.state.display === 0) {
    return (
      <div className="Container">
      <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })} className={'tab-wrap'}>
        <TabList>
          <Tab><span>1</span> Personal Details</Tab>
          <Tab><span>2</span> Company Details</Tab>
          <Tab><span>3</span> Email Verification</Tab>
        </TabList>

        <TabPanel>
          <PersonalForm
            name = {this.state.name}
            country = {this.state.country}
            state = {this.state.state}
            gender = {this.state.gender}
            phone = {this.state.phone}
            errors = {this.state.errors}
            handleChange = {this.handleChange}
            changeNext = {this.handleNext}
            handleRadio = {this.handleRadio}
            handleFlag = {this.handleFlag}
            handleState = {this.handleState}
          />
        </TabPanel>
        <TabPanel>
          <CompanyDetails
            companyname = {this.state.companyname}
            errors = {this.state.errors}
            emailId = {this.state.emailId}
            jobtitle = {this.state.jobtitle}
            experience = {this.state.experience}
            condition = {this.state.condition}
            handleChange = {this.handleChange}
            changeNext = {this.handleSendOtp}
            changeBack = {this.handleBack}
            onChangeFile = {this.onChangeFile}
        />
        </TabPanel>
        <TabPanel>
          <EmailDetails

            otp = {this.state.otp}
            errors = {this.state.errors}
            handleOtp = {this.handleOtp}  
            changeBack = {this.handleBack}
            handleSubmit = {this.handleSubmit}
          />
        </TabPanel>
      </Tabs>
      </div>
    );} else {
      return (
      <Success/>
      );
    }
  }
}

export default App;