import React from 'react'
import OtpInput from 'react-otp-input';

export default function EmailDetails(props) {
    let errors = props.errors;
  return (
      <React.Fragment>
        <div className="container">
        <div className="form-wrap otp">
        <div className="form-group otp-form">
        <label htmlFor="password">Enter Your Code:</label>
         <OtpInput  
          numInputs={4}
          separator={<span>-</span>
          }
          value={props.otp}
          onChange = {props.handleOtp}
          
        />
        <span className='error'>
        { errors.otp.length> 0 ? errors.otp : ''}</span>
    </div>
    <button className="btn btn-primary" onClick={props.changeBack} >Back</button>
    <button className="btn btn-secondary" type="submit" onClick={props.handleSubmit}>Verify</button>
    </div>
    </div>
    </React.Fragment>
    );
}

