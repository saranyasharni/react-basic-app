import React, {Component} from 'react'

class CompanyDetails extends Component {
	render() {
    let errors = this.props.errors;
    return(
      <div className="container">
        <div className="form-wrap">
      <div className="form-group upload-wrap">

        <img src={this.props.logo} alt= 'no' className="upload" />

        <label htmlFor="file" className="logo"> Upload Your Company Logo</label>
        <input
          className="form-control"
          onChange = {this.props.onChangeFile}
          id="file"
          name="file"
          type="file"
        />
        
        <span className='error'>
          { errors.file.length> 0 ? errors.file : ''}
        </span>
        
      </div>
      <div className="form-group">
        <label htmlFor="companyname">Company Name</label>
        <input
          className="form-control"
          name="companyname"
          type="text"
          value={this.props.companyname}
          onChange={this.props.handleChange}
        />
        <span className='error'>
          { errors.companyname.length> 0 ? errors.companyname : ''}</span>
      </div>
    
      <div className="form-group">
        <label htmlFor="emailid">Email Id</label>
        <input
          className="form-control"
          id="emailid"
          name="emailId"
          type="text"
          value={this.props.emailId}
          onChange={this.props.handleChange}
        />
        <span className='error'>
          { errors.emailId.length> 0 ? errors.emailId : ''}</span>
      </div>
      <div className="form-group">
        <label htmlFor="jobtitle">Job Title</label>
        <input
          className="form-control"
          id="jobtitle"
          name="jobtitle"
          type="text"
          value={this.props.jobtitle}
          onChange={this.props.handleChange}
        />
        <span className='error'>
          { errors.jobtitle.length> 0 ? errors.jobtitle : ''}</span>
      </div>
      <div className="form-group">
        <label htmlFor="exp">Years of Experience</label>
        <input
          className="form-control"
          id="exp"
          name="experience"
          type="text"
          value={this.props.experience}
          onChange={this.props.handleChange}
        />
        <span className='error'>
          { errors.experience.length> 0 ? errors.experience : ''}</span>
      </div>
      <div className="form-group">
        <input
          id="condition"
          name="condition"
          type ="checkbox"
          checked = {this.props.condition}
          onChange={this.props.handleChange}
        />
        <label htmlFor="condition" className="terms">I accept the terms and conditions</label>
        <br/>
        <span className='error'>
          { errors.condition.length> 0 ? errors.condition : ''}</span>
      </div>
      <button className="btn btn-primary" onClick={this.props.changeBack}>Back </button>
      <button className="btn btn-secondary" onClick={this.props.changeNext}>Send OTP</button>
      </div>
      </div>
    );
  }
}
export default CompanyDetails;