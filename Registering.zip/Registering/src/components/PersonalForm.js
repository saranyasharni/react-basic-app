import React, {Component} from 'react'
import 'react-dropdown/style.css';
import 'react-flags-select/css/react-flags-select.css';
import {locations} from './Locations.jsx'
import {countries} from './Countries.jsx'

class PersonalForm extends Component {
	render() {
		let errors = this.props.errors;
	    return(
	    <div className= "container">
		<div className="form-wrap">
	    <div className="form-group">
        <label htmlFor="name">Full Name</label>
        <input
          className="form-control"
          name="name"
          type="text"
          value={this.props.name}
          onChange={this.props.handleChange}
        />
        <span className='error'>
        { errors.name.length> 0 ? errors.name : ''}</span>
      	</div>
	    <div className="form-group">
	    <label htmlFor="name">Gender</label>
	    <ul className="donate-now">
		  <li>
		    <input type="radio" id="radio1" 
		    value="male" 
        	onChange = {this.props.handleChange}
        	checked={this.props.gender === "male"} 
        	name="gender" />
		    <label htmlFor="radio1">Male</label>
		  </li>
		  <li>
		    <input type="radio" id="radio2" 
		    value="female" 
        	onChange = {this.props.handleChange}
        	checked = {this.props.gender === "female"} 
        	name="gender" />
		    <label htmlFor="radio2">Female</label>
		  </li>
		    <li>
		    <input type="radio" id="radio3" 
		    value="others" 
        	onChange = {this.props.handleChange}
        	checked = {this.props.gender === "others"} 
        	name="gender" />
		    <label htmlFor="radio3">Others</label>
		  </li>
		  
  		</ul>
  		<span className='error'>
          	{errors.gender.length> 0 ? errors.gender : ''}
          </span>
	   	</div>
	      	<div className="form-group">
	      	<label htmlFor="gender">Country:</label>
	      	<select id="dropdown" 
	      	  value = {this.props.country}
	      	  name = "country"
	      	  className = "form-control"
	      	  onChange = {this.props.handleChange}>
	      	  {countries.map(option => (
          		<option key={option.code} value={option.name}>
            	{option.name} 
          		</option>
        	  ))}
            </select>
            <span className='error'>
        		{errors.country.length> 0 ? errors.country : ''}
        	</span>
    		</div>
    		<div className="form-group">
	      	<label htmlFor="gender">State:</label>
	      	  <select id="dropdown" 
	      	  name = "state"
	      	  value= {this.props.state}
	      	  className = "form-control" 
	      	  onChange={this.props.handleChange}
	      	  >
	      	  {locations.map(option => (
          		<option key={option.key} value={option.name}>
            	{option.name} 
          		</option>
        	  ))}
            </select>
            <span className='error'>
        	{ errors.state.length> 0 ? errors.state : ''}</span>
    		</div>
	      	<div className="form-group">
	      	<label htmlFor="number">PhoneNumber:</label>
		       	<input 
	            type= "number" 
	            name = "phone"
	            onChange={this.props.handleChange} 
	            className="form-control"
	            value = {this.props.phone} 
	            id="number"/>
	        <span className='error'>
        	{ errors.phone.length> 0 ? errors.phone : ''}</span>
	      	</div>

	      	<div className="form-group nex-btn">
	        	<button type="submit" className="btn btn-default btn-secondary" onClick={this.props.changeNext}>Next</button>
	      	</div>
			  </div>
	      	</div>
	    )
		}
	}
export default PersonalForm;